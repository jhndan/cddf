#define SAMPLE_OUTPUT                                                          \
    {                                                                          \
        0x50401000, 0xffffffff, 0x00000002, 0x000091b7, 0xffff6de1, 0x00000000 \
    }
